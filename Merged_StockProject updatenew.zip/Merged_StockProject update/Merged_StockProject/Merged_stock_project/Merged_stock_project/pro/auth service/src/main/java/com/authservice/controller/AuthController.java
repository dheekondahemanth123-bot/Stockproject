package com.authservice.controller;

import com.authservice.dto.AuthResponse;
import com.authservice.dto.LoginRequest;
import com.authservice.dto.MessageResponse;
import com.authservice.dto.RegisterRequest;
import com.authservice.dto.VerifyOtpRequest;
import com.authservice.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    // ─── POST /auth/register ───────────────────────────────
    @PostMapping("/register")
    public ResponseEntity<MessageResponse> register(
            @Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.status(201)
                .body(authService.register(request));
    }

    // ─── POST /auth/login ───────────────────────────────────
    // May return JWT OR OTP message
    @PostMapping("/login")
    public ResponseEntity<?> login(
            @Valid @RequestBody LoginRequest request) {

        Object response = authService.login(request);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/verify-login-otp")
    public ResponseEntity<AuthResponse> verifyLoginOtp(
            @RequestBody VerifyOtpRequest request) {

        return ResponseEntity.ok(
                authService.verifyLoginOtp(request.getEmail(), request.getOtp())
        );
    }

    // ─── POST /auth/mfa ────────────────────────────────────
    @PostMapping("/mfa")
    public ResponseEntity<MessageResponse> toggleMfa(
            @RequestParam String email,
            @RequestParam boolean enable) {

        return ResponseEntity.ok(
                authService.toggleMfa(email, enable));
    }

    // ─── POST /auth/logout ─────────────────────────────────
    @PostMapping("/logout")
    public ResponseEntity<MessageResponse> logout() {
        return ResponseEntity.ok(authService.logout());
    }
}
package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.AdvisorDTO;
import com.example.demo.dto.BuyRequestDTO;
import com.example.demo.dto.CompanyDTO;
import com.example.demo.dto.RequestAdvisorDto;
import com.example.demo.dto.SellRequestDTO;
import com.example.demo.dto.StockDTO;
import com.example.demo.dto.TransferRequestDTO;
import com.example.demo.entity.Holding;
import com.example.demo.entity.Transaction;
import com.example.demo.service.InvestorService;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/api/investor")
public class InvestorController {

	@Autowired
	InvestorService service;

	@GetMapping("/companyList")
	public List<CompanyDTO> getCompanies() {
	    return service.getCompanyList();
	}
	@GetMapping("/stockList")
	public List<StockDTO> getStocks() {
	    return service.getStockList();
	}

	@GetMapping("/searchAdvisor")
	public List<AdvisorDTO> advisor() {
	    return service.getAdvisorList();
	}
	
	@GetMapping("/getAdvice")
	public String getAdvice(@RequestParam("question") String question) {
	    return service.getAdvice(question);
	}
	
	@PostMapping("/buy")
	public String buyStock(@Valid @RequestBody BuyRequestDTO dto)
	{
		return service.buyStock(dto);
	}

	@PostMapping("/sell")
	public String sell(@Valid @RequestBody SellRequestDTO dto) {
		return service.sellStock(dto);
	}

	@PostMapping("/transfer")
	public String transfer(@Valid @RequestBody TransferRequestDTO dto) {
		return service.transferMoney(dto);
	}
	

	@GetMapping("/transactions/{investorId}")
	public List<Transaction> history(@PathVariable Long investorId) {
	    return service.history(investorId);
	}
	
	@GetMapping("advisor/list/all")
	public List<AdvisorDTO> getAllAdvisor(){
		return service.getAdvisorList();
	}
	@PostMapping("select/advisor")
	public String selectAdvisor(@RequestBody RequestAdvisorDto requestAdvisor) {
		return service.allocateAdvisor(requestAdvisor);
	}

	@GetMapping("/holding/{investorId}")
	public List<Holding> getHolding(@PathVariable Long investorId) {
		return service.getHolding(investorId);
	}
}
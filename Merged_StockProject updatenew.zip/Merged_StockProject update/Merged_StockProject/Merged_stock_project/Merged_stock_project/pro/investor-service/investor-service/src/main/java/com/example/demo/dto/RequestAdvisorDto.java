package com.example.demo.dto;

import lombok.Data;

@Data
public class RequestAdvisorDto {
	private Long investorId;
	private Long advisorId;
}

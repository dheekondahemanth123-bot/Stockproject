package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.example.demo.model.Notification;

import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    // ✅ 1. SEND EMAIL WITH PDF (BUY / SELL)
    public void sendEmailWithAttachment(Notification notification, byte[] pdfBytes) {

        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper =
                    new MimeMessageHelper(mimeMessage, true);

            helper.setTo(notification.getEmail());
            helper.setSubject("Transaction Confirmation");
            helper.setText(notification.getMessage(), false);

            helper.addAttachment(
                    "TransactionReceipt.pdf",
                    new ByteArrayResource(pdfBytes)
            );

            mailSender.send(mimeMessage);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✅ 2. SEND SIMPLE EMAIL (OTP / REGISTRATION)
    public void sendSimpleEmail(String toEmail, String subject, String body) {

        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper =
                    new MimeMessageHelper(mimeMessage, false);

            helper.setTo(toEmail);
            helper.setSubject(subject);
            helper.setText(body, false);

            mailSender.send(mimeMessage);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
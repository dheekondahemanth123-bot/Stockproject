package com.example.demo.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
public class InvestorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    // ✅ Test Company List API
    @Test
    public void testCompanyList() throws Exception {

        mockMvc.perform(get("/investor/list"))
                .andExpect(status().isOk());
    }


    // ✅ Test Advisor List API
    @Test
    public void testAdvisorList() throws Exception {

        mockMvc.perform(get("/investor/searchAdvisor"))
                .andExpect(status().isOk());
    }


    // ✅ Test Buy API Validation Error
//    @Test
//    public void testBuyValidation() throws Exception {
//
//        String json = """
//        {
//        "investorId": null,
//        "assetName":"",
//        "quantity":0,
//        "price":0
//        }
//        """;
//
//        mockMvc.perform(post("/investor/buy")
//                .contentType("application/json")
//                .content(json))
//                .andExpect(status().isBadRequest());
//    }

}	
package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dto.NotificationRequest;

@Service
public class NotificationClient {

    @Autowired
    RestTemplate restTemplate;

    public void sendEmail(String email,String message)
    {

        NotificationRequest request =
                new NotificationRequest();

        request.setEmail(email);
        request.setMessage(message);

        restTemplate.postForObject(
        "http://localhost:8087/notification/send",
        request,
        String.class);

    }

}
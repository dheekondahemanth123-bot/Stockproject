package com.example.demo.dto;

import jakarta.validation.constraints.*;
public class SellRequestDTO {

	@NotNull(message="Investor Id required")
	private Long investorId;

	@NotBlank(message="Stock name required")
	private String assetName;

	@Min(value=1,message="Quantity must be > 0")
	private int quantity;

	@Min(value=1,message="Price must be > 0")
	private double price;

	

	public Long getInvestorId() {
		return investorId;
	}

	public void setInvestorId(Long investorId) {
		this.investorId = investorId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
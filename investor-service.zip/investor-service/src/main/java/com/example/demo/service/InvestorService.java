package com.example.demo.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.BuyRequestDTO;
import com.example.demo.dto.SellRequestDTO;
import com.example.demo.dto.TransferRequestDTO;
import com.example.demo.entity.Investor;
import com.example.demo.entity.Transaction;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.InvestorRepository;
import com.example.demo.repository.TransactionRepository;
import com.example.demo.entity.Holding;
import com.example.demo.repository.HoldingRepository;


@Service
public class InvestorService {

	@Autowired
	InvestorRepository repo;

	@Autowired
	TransactionRepository tRepo;

	@Autowired
	HoldingRepository hRepo;
	
	@Autowired
	NotificationClient notificationClient;

	public String buyStock(BuyRequestDTO dto) {

	    Investor investor = repo.findById(dto.getInvestorId())
	            .orElseThrow(() ->
	                    new ResourceNotFoundException("Investor not found"));

	    double total = dto.getQuantity() * dto.getPrice();

	    if (investor.getBalance() < total) {
	        return "Insufficient Balance";
	    }

	    investor.setBalance(investor.getBalance() - total);

	    repo.save(investor);

	    /* HOLDING SAVE */

	    Holding h = hRepo.findByInvestorIdAndAssetName(
	            dto.getInvestorId(),
	            dto.getAssetName());

	    if (h == null) {

	        h = new Holding();
	        h.setInvestorId(dto.getInvestorId());
	        h.setAssetName(dto.getAssetName());
	        h.setQuantity(dto.getQuantity());

	    } else {

	        h.setQuantity(h.getQuantity() + dto.getQuantity());
	    }

	    hRepo.save(h);

	    /* TRANSACTION */

	    Transaction t = new Transaction();
	    t.setInvestorId(dto.getInvestorId());
	    t.setType("BUY");
	    t.setAssetName(dto.getAssetName());
	    t.setQuantity(dto.getQuantity());
	    t.setPrice(dto.getPrice());
	    t.setDate(LocalDate.now().toString());

	    tRepo.save(t);

	    /* ✅ PROFESSIONAL EMAIL FORMAT */

	    String message = String.format("""
	Subject: Transaction Confirmation: %s

	Dear %s,

	This is to confirm that your request to Buy has been successfully processed.
	Please find the details of your transaction below:

	Stock Asset: %s
	Execution Price: $%.2f
	Quantity: %d
	Total Value: $%.2f
	Remaining Balance: $%.2f

	Thank you for choosing our platform for your investment needs.
	""",
	            dto.getAssetName(),
	            investor.getInvestorName(),
	            dto.getAssetName(),
	            dto.getPrice(),
	            dto.getQuantity(),
	            total,
	            investor.getBalance()
	    );

	    notificationClient.sendEmail(
	            investor.getEmail(),
	            message
	    );

	    return "Stock Bought Successfully";
	}

	public String sellStock(SellRequestDTO dto) {

	    Investor investor = repo.findById(dto.getInvestorId())
	            .orElseThrow(() ->
	                    new ResourceNotFoundException("Investor not found"));

	    Holding h = hRepo.findByInvestorIdAndAssetName(
	            dto.getInvestorId(),
	            dto.getAssetName());

	    if (h == null) {
	        return "Stock not found";
	    }

	    if (h.getQuantity() < dto.getQuantity()) {
	        return "Not enough stock";
	    }

	    double total = dto.getQuantity() * dto.getPrice();

	    /* UPDATE BALANCE */

	    investor.setBalance(investor.getBalance() + total);
	    repo.save(investor);

	    /* REDUCE HOLDING */

	    h.setQuantity(h.getQuantity() - dto.getQuantity());
	    hRepo.save(h);

	    /* SAVE TRANSACTION */

	    Transaction t = new Transaction();
	    t.setInvestorId(dto.getInvestorId());
	    t.setType("SELL");
	    t.setAssetName(dto.getAssetName());
	    t.setQuantity(dto.getQuantity());
	    t.setPrice(dto.getPrice());
	    t.setDate(LocalDate.now().toString());

	    tRepo.save(t);

	    /* ✅ PROFESSIONAL EMAIL FORMAT */

	    String message = String.format("""
	Subject: Transaction Confirmation: %s

	Dear %s,

	This is to confirm that your request to Sell has been successfully processed.
	Please find the details of your transaction below:

	Stock Asset: %s
	Execution Price: $%.2f
	Quantity: %d
	Total Value: $%.2f
	Updated Balance: $%.2f

	Transaction Type: SELL
	Transaction Date: %s

	Thank you for choosing our platform for your investment needs.
	""",
	            dto.getAssetName(),
	            investor.getInvestorName(),
	            dto.getAssetName(),
	            dto.getPrice(),
	            dto.getQuantity(),
	            total,
	            investor.getBalance(),
	            t.getDate()
	    );

	    notificationClient.sendEmail(
	            investor.getEmail(),
	            message
	    );

	    return "Stock Sold Successfully";
	}
	
	
	public String transferMoney(TransferRequestDTO dto) {

	    Investor fromInvestor =
	            repo.findById(dto.getFromInvestorId())
	                    .orElse(null);

	    Investor toInvestor =
	            repo.findById(dto.getToInvestorId())
	                    .orElse(null);

	    if (fromInvestor == null || toInvestor == null) {
	        return "Investor not found";
	    }

	    if (fromInvestor.getBalance() < dto.getAmount()) {
	        return "Insufficient Balance";
	    }

	    double amount = dto.getAmount();
	    String date = LocalDate.now().toString();

	    /* DEDUCT FROM SENDER */
	    fromInvestor.setBalance(fromInvestor.getBalance() - amount);

	    /* ADD TO RECEIVER */
	    toInvestor.setBalance(toInvestor.getBalance() + amount);

	    repo.save(fromInvestor);
	    repo.save(toInvestor);

	    /* ✅ EMAIL TO SENDER */

	    String senderMessage = String.format("""
	Subject: Transaction Confirmation: Fund Transfer

	Dear %s,

	This is to confirm that your request to Transfer has been successfully processed.
	Please find the details of your transaction below:

	Transfer Amount: $%.2f
	Transferred To: %s
	Remaining Balance: $%.2f

	Transaction Type: TRANSFER
	Transaction Date: %s

	Thank you for choosing our platform for your investment needs.
	""",
	            fromInvestor.getInvestorName(),
	            amount,
	            toInvestor.getInvestorName(),
	            fromInvestor.getBalance(),
	            date
	    );

	    notificationClient.sendEmail(
	            fromInvestor.getEmail(),
	            senderMessage
	    );

	    /* ✅ EMAIL TO RECEIVER */

	    String receiverMessage = String.format("""
	Subject: Transaction Confirmation: Funds Received

	Dear %s,

	You have successfully received funds.
	Please find the details below:

	Received Amount: $%.2f
	Received From: %s
	Updated Balance: $%.2f

	Transaction Type: TRANSFER
	Transaction Date: %s

	Thank you for choosing our platform for your investment needs.
	""",
	            toInvestor.getInvestorName(),
	            amount,
	            fromInvestor.getInvestorName(),
	            toInvestor.getBalance(),
	            date
	    );

	    notificationClient.sendEmail(
	            toInvestor.getEmail(),
	            receiverMessage
	    );

	    return "Transfer Successful";
	}

	public List<Transaction> history(Long id) {
		return tRepo.findByInvestorId(id);
	}

	public List<Holding> getHolding(Long id) {
		return hRepo.findByInvestorId(id);
	}

}
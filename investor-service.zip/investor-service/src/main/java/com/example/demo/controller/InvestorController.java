package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.BuyRequestDTO;
import com.example.demo.dto.SellRequestDTO;
import com.example.demo.dto.TransferRequestDTO;
import com.example.demo.entity.Holding;
import com.example.demo.entity.Transaction;
import com.example.demo.service.InvestorService;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/investor")

public class InvestorController {

	@Autowired
	InvestorService service;

	@GetMapping("/list")
	public String list() {
		return "Company List";
	}

	@GetMapping("/searchAdvisor")
	public String advisor() {
		return "Advisor List";
	}

	@PostMapping("/buy")
	public String buyStock(@Valid @RequestBody BuyRequestDTO dto)
	{
		return service.buyStock(dto);
	}

	@PostMapping("/sell")
	public String sell(@Valid @RequestBody SellRequestDTO dto) {
		return service.sellStock(dto);
	}

	@PostMapping("/transfer")
	public String transfer(@Valid @RequestBody TransferRequestDTO dto) {
		return service.transferMoney(dto);
	}

	@GetMapping("/history/{id}")
	public List<Transaction> history(@PathVariable Long id) {
		return service.history(id);
	}

	@GetMapping("/holding/{id}")
	public List<Holding> getHolding(@PathVariable Long id) {
		return service.getHolding(id);
	}
}
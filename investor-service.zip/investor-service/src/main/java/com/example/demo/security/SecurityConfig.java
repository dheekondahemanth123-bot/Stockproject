package com.example.demo.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.core.userdetails.*;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration

public class SecurityConfig {

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

		http

				.csrf(csrf -> csrf.disable())

				.authorizeHttpRequests(auth -> auth

						/* PUBLIC APIs */

						.requestMatchers("/investor/list").permitAll()

						.requestMatchers("/investor/searchAdvisor").permitAll()

						/* INVESTOR APIs */

						.requestMatchers("/investor/buy").hasRole("INVESTOR")

						.requestMatchers("/investor/sell").hasRole("INVESTOR")

						.requestMatchers("/investor/transfer").hasRole("INVESTOR")

						

						/* ADMIN APIs */

						.requestMatchers("/investor/history/**").hasAnyRole("INVESTOR","ADMIN")
						
						.requestMatchers("/investor/holding/**").hasAnyRole("INVESTOR","ADMIN")

						.anyRequest().authenticated()

				)

				.httpBasic(Customizer.withDefaults());

		return http.build();

	}

	/* USERS */

	@Bean
	public UserDetailsService userDetailsService() {

		UserDetails investor = User.withUsername("investor").password("{noop}1234").roles("INVESTOR").build();

		UserDetails admin = User.withUsername("admin").password("{noop}admin123").roles("ADMIN").build();

		return new InMemoryUserDetailsManager(investor, admin);

	}

}
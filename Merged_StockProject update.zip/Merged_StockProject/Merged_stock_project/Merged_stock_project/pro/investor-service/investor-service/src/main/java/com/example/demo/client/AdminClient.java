package com.example.demo.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.CompanyDTO;
import com.example.demo.dto.StockDTO;
import com.example.demo.dto.UpdateQuantity;

@FeignClient(name = "admin", url = "http://localhost:8086")
public interface AdminClient {

    // Companies
    @GetMapping("/admin/companies")
    List<CompanyDTO> getAllCompanies();

    // Stocks
    @GetMapping("/admin/stocks")
    List<StockDTO> getAllStocks();

    @GetMapping("/admin/stocks/{symbol}")
    StockDTO getStock(@PathVariable("symbol") String symbol);

    @PutMapping("/admin/stocks/update-quantity-buy")
    StockDTO updateQuantityBuy(@RequestBody UpdateQuantity request);

    @PutMapping("/admin/stocks/update-quantity-sell")
    StockDTO updateQuantitySell(@RequestBody UpdateQuantity request);
}
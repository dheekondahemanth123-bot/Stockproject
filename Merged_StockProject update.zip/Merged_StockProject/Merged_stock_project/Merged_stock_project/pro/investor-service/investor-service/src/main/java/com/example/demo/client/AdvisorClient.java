package com.example.demo.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dto.AdvisorDTO;

@FeignClient(name = "advisor", url = "http://localhost:8084")
public interface AdvisorClient {

    @GetMapping("/advisor/list/all")
    List<AdvisorDTO> getAdvisors();
    
    @GetMapping("/chatbot/ask")
     String getAdvice(@RequestParam("question")  String question);
}